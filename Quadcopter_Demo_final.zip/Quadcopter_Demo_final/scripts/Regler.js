var last_pos_x = 0.0;
var last_pos_y = 0.0;   // Actually z-axis in Babylon allocation!

var integral_x = 0;
var integral_y = 0;

//var x_Anfang=0;
//var y_Anfang=0;

var dt = 0.025;         // Even more precise calculation


var kp = 0;
var ki = 0;
var kd = 0;



var use_p = true;
var use_i = true;
var use_d = true;



function initRegler() {

}


function updateRegler(pos_x, pos_y ) {

	// Get current state of checkboxes
	use_p = document.getElementById("p_checkbox").checked;
	use_i = document.getElementById("i_checkbox").checked;
	use_d = document.getElementById("d_checkbox").checked;

	// Get new gain values

   // x_Anfang = document.getElementById("x_position").value;
   // y_Anfang = document.getElementById("y_position").value;



	kp = document.getElementById("p_gain").value;
	ki = document.getElementById("i_gain").value;
	kd = document.getElementById("d_gain").value;



    var pos_x_diff = (pos_x - last_pos_x)/dt;               // time-differential of x-position
    integral_x += pos_x;								    // integral of x-position

    var pos_y_diff = (pos_y - last_pos_y)/dt;               // time-differential of y-position
    integral_y += pos_y;									// integral of y-position

    var kp_use = 0;
    var ki_use = 0;
    var kd_use = 0;

    // Choose Controller
    if(use_p){
    	kp_use = kp;
    }
    if(use_i){
    	ki_use = ki;
    }
    if(use_d){
    	kd_use = kd;
    }


    mv_xangle = kp_use*pos_x + ki_use*integral_x + kd_use*pos_x_diff;      // PID
    mv_yangle = kp_use*pos_y + ki_use*integral_y + kd_use*pos_y_diff;      // PID
    pos_x = kp_use*pos_x + ki_use*integral_x + kd_use*pos_x_diff;      // PID
    pos_y = kp_use*pos_y + ki_use*integral_y + kd_use*pos_y_diff;     // PID
    /*pos_x = (r+kp_use*i/40)*Math.cos(i/d) + ki_use*integral_x + kd_use*pos_x_diff;      // PID
    pos_y = (r+kp_use*i/40)*Math.sin(i/d) + ki_use*integral_y + kd_use*pos_y_diff;*/
   /* if (mv_xangle<-Math.PI/4) {
        mv_xangle=-Math.PI/4;
    }
    else if (mv_xangle>Math.PI/4) {
        mv_xangle=Math.PI/4;
    }
    if (mv_yangle>Math.PI/4) {
        mv_yangle=Math.PI/4;
    }
    else if (mv_yangle<-Math.PI/4) {
        mv_yangle=-Math.PI/4;
    } */


    //Update Plot
	plot_x_time_series.append(new Date().getTime(), pos_x);                // plot for x position
	mv_xangle_time_series.append(new Date().getTime(), mv_xangle);          // plot for x angle of quadcopter
    plot_y_time_series.append(new Date().getTime(), pos_y);                // plot for y position
    mv_yangle_time_series.append(new Date().getTime(), mv_yangle);         // plot for y angle of quadcopter

    /****************************
    plot_x_time_series.append(new Date().getTime(), mv_xangle);                // plot for x position
    //mv_xangle_time_series.append(new Date().getTime(), mv_xangle);          // plot for x angle of quadcopter
    plot_y_time_series.append(new Date().getTime(), mv_yangle);                // plot for y position
   // mv_yangle_time_series.append(new Date().getTime(), mv_yangle);          // plot for y angle of quadcopter
    ***************************/

    last_pos_x = pos_x; //  update last x-position
    last_pos_y = pos_y; //  update last y-position

    //return new BABYLON.Quaternion(-mv_yangle, 0, mv_xangle, 1).normalize(); //  manipulated variable is x-angle and y-angle of table
    return new BABYLON.Quaternion(-pos_y, 0, pos_x, 1 ).normalize();

}
