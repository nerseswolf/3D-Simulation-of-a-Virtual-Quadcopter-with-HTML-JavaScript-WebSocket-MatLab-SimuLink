//
// File: XsensWebSocketAngleRefBandTest_v4_5_1_data.cpp
//
// Code generated for Simulink model 'XsensWebSocketAngleRefBandTest_v4_5_1'.
//
// Model version                  : 1.88
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Tue Jul 18 14:05:15 2017
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "XsensWebSocketAngleRefBandTest_v4_5_1.h"
#include "XsensWebSocketAngleRefBandTest_v4_5_1_private.h"

// Block parameters (auto storage)
P_XsensWebSocketAngleRefBandT_T XsensWebSocketAngleRefBandTes_P = {
  1.0,                                 // Mask Parameter: CompareToConstant_const
                                       //  Referenced by: '<S1>/Constant'

  1.0,                                 // Expression: 1
                                       //  Referenced by: '<Root>/Switch1'

  0.0,                                 // Expression: correction
                                       //  Referenced by: '<S2>/Extractor'

  -45.0,                               // Expression: -45
                                       //  Referenced by: '<S6>/Switch2'

  45.0,                                // Expression: 45
                                       //  Referenced by: '<S6>/Switch'

  -45.0,                               // Expression: -45
                                       //  Referenced by: '<S6>/Switch3'

  45.0,                                // Expression: 45
                                       //  Referenced by: '<S6>/Switch1'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition1'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition6'


  //  Computed Parameter: TransferFcn_A
  //  Referenced by: '<S6>/Transfer Fcn'

  { -1.0, -0.0 },

  //  Computed Parameter: TransferFcn_C
  //  Referenced by: '<S6>/Transfer Fcn'

  { 0.0, 100.0 },
  50.0,                                // Expression: 50
                                       //  Referenced by: '<S6>/Saturation'

  -50.0,                               // Expression: -50
                                       //  Referenced by: '<S6>/Saturation'


  //  Computed Parameter: TransferFcn1_A
  //  Referenced by: '<S6>/Transfer Fcn1'

  { -1.0, -0.0 },

  //  Computed Parameter: TransferFcn1_C
  //  Referenced by: '<S6>/Transfer Fcn1'

  { 0.0, 100.0 },
  50.0,                                // Expression: 50
                                       //  Referenced by: '<S6>/Saturation1'

  -50.0,                               // Expression: -50
                                       //  Referenced by: '<S6>/Saturation1'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition7'


  //  Expression: [0 0]
  //  Referenced by: '<S4>/Constant'

  { 0.0, 0.0 },
  0.0,                                 // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition8'

  1.0,                                 // Expression: 1
                                       //  Referenced by: '<S4>/Switch'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S4>/Integrator'

  -100.0,                              // Computed Parameter: TransferFcn2_A
                                       //  Referenced by: '<S4>/Transfer Fcn2'

  -10000.0,                            // Computed Parameter: TransferFcn2_C
                                       //  Referenced by: '<S4>/Transfer Fcn2'

  100.0,                               // Computed Parameter: TransferFcn2_D
                                       //  Referenced by: '<S4>/Transfer Fcn2'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S4>/Integrator1'

  -100.0,                              // Computed Parameter: TransferFcn1_A_g
                                       //  Referenced by: '<S4>/Transfer Fcn1'

  -10000.0,                            // Computed Parameter: TransferFcn1_C_m
                                       //  Referenced by: '<S4>/Transfer Fcn1'

  100.0,                               // Computed Parameter: TransferFcn1_D
                                       //  Referenced by: '<S4>/Transfer Fcn1'


  //  Expression: [0 0]
  //  Referenced by: '<S5>/Constant'

  { 0.0, 0.0 },
  1.0,                                 // Expression: 1
                                       //  Referenced by: '<S5>/Switch'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S5>/Integrator'

  -100.0,                              // Computed Parameter: TransferFcn2_A_l
                                       //  Referenced by: '<S5>/Transfer Fcn2'

  -10000.0,                            // Computed Parameter: TransferFcn2_C_c
                                       //  Referenced by: '<S5>/Transfer Fcn2'

  100.0,                               // Computed Parameter: TransferFcn2_D_c
                                       //  Referenced by: '<S5>/Transfer Fcn2'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S5>/Integrator1'

  -100.0,                              // Computed Parameter: TransferFcn1_A_b
                                       //  Referenced by: '<S5>/Transfer Fcn1'

  -10000.0,                            // Computed Parameter: TransferFcn1_C_n
                                       //  Referenced by: '<S5>/Transfer Fcn1'

  100.0,                               // Computed Parameter: TransferFcn1_D_o
                                       //  Referenced by: '<S5>/Transfer Fcn1'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition11'

  1.0,                                 // Expression: 1
                                       //  Referenced by: '<Root>/Switch'

  1.5,                                 // Expression: 1.5
                                       //  Referenced by: '<Root>/Saturation'

  -1.5,                                // Expression: -1.5
                                       //  Referenced by: '<Root>/Saturation'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S6>/Constant'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S6>/Constant1'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S6>/Switch4'

  0.0,                                 // Expression: 0
                                       //  Referenced by: '<S6>/Switch5'

  0,                                   // Computed Parameter: RateTransition_X0
                                       //  Referenced by: '<Root>/Rate Transition'

  100U,                                // Expression: uint32(Freq)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  1U,                                  // Expression: uint32(UseCalibratedValues)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  5U,                                  // Computed Parameter: WebSocketServerSFunction_p7
                                       //  Referenced by: '<S7>/WebSocketServer SFunction'

  9999U,                               // Computed Parameter: WebSocketServerSFunction_p9
                                       //  Referenced by: '<S7>/WebSocketServer SFunction'


  //  Expression: uint8(SID00)'
  //  Referenced by: '<Root>/Xsens IMUs'

  { 47U, 100U, 101U, 118U, 47U, 120U, 115U, 101U, 110U, 115U, 95U, 100U, 111U,
    110U, 103U, 108U, 101U, 95U, 49U },

  //  Expression: uint8(SID01)'
  //  Referenced by: '<Root>/Xsens IMUs'

  { 51U, 52U, 48U, 52U, 53U, 52U },
  48U,                                 // Expression: uint8(SID02)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID03)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID04)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID05)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID06)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID07)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID08)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID09)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID10)'
                                       //  Referenced by: '<Root>/Xsens IMUs'


  //  Computed Parameter: WebSocketServerSFunction_p1
  //  Referenced by: '<S7>/WebSocketServer SFunction'

  { 1U, 3U, 2U, 1U, 1U },

  //  Computed Parameter: WebSocketServerSFunction_p2
  //  Referenced by: '<S7>/WebSocketServer SFunction'

  { 1U, 4U, 2U, 2U, 2U },

  //  Computed Parameter: WebSocketServerSFunction_p3
  //  Referenced by: '<S7>/WebSocketServer SFunction'

  { 0U, 0U, 0U, 0U, 0U },

  //  Expression: unicode2native(jsonBlockConfig, 'ISO-8859-1')
  //  Referenced by: '<S7>/WebSocketServer SFunction'

  { 123U, 34U, 73U, 110U, 112U, 117U, 116U, 78U, 97U, 109U, 101U, 115U, 34U, 58U,
    32U, 91U, 34U, 116U, 105U, 109U, 101U, 34U, 44U, 34U, 113U, 117U, 97U, 116U,
    34U, 44U, 34U, 117U, 34U, 44U, 34U, 121U, 34U, 44U, 34U, 101U, 114U, 114U,
    111U, 114U, 34U, 93U, 44U, 34U, 79U, 117U, 116U, 112U, 117U, 116U, 78U, 97U,
    109U, 101U, 115U, 34U, 58U, 32U, 91U, 34U, 115U, 116U, 111U, 112U, 34U, 44U,
    34U, 80U, 97U, 114U, 97U, 109U, 101U, 116U, 101U, 114U, 34U, 44U, 34U, 114U,
    34U, 44U, 34U, 117U, 95U, 109U, 111U, 97U, 34U, 44U, 34U, 75U, 111U, 85U,
    34U, 93U, 125U },

  //  Expression: unicode2native(address, 'ISO-8859-1')
  //  Referenced by: '<S7>/WebSocketServer SFunction'

  { 108U, 111U, 99U, 97U, 108U, 104U, 111U, 115U, 116U },

  //  Expression: unicode2native(resource, 'ISO-8859-1')
  //  Referenced by: '<S7>/WebSocketServer SFunction'

  { 47U, 119U, 115U }
};

//
// File trailer for generated code.
//
// [EOF]
//
