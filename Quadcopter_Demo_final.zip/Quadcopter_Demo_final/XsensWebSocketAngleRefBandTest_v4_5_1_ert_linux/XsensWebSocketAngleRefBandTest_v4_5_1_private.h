//
// File: XsensWebSocketAngleRefBandTest_v4_5_1_private.h
//
// Code generated for Simulink model 'XsensWebSocketAngleRefBandTest_v4_5_1'.
//
// Model version                  : 1.88
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Tue Jul 18 14:05:15 2017
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_XsensWebSocketAngleRefBandTest_v4_5_1_private_h_
#define RTW_HEADER_XsensWebSocketAngleRefBandTest_v4_5_1_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"

// Private macros used by the generated code to access rtModel
#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

int_T rt_WriteMat4FileHeader(FILE *fp,
  int32_T m,
  int32_T n,
  const char_T *name);

// private model entry point functions
extern void XsensWebSocketAngleRefBandTest_v4_5_1_derivatives(void);

#endif                                 // RTW_HEADER_XsensWebSocketAngleRefBandTest_v4_5_1_private_h_ 

//
// File trailer for generated code.
//
// [EOF]
//
