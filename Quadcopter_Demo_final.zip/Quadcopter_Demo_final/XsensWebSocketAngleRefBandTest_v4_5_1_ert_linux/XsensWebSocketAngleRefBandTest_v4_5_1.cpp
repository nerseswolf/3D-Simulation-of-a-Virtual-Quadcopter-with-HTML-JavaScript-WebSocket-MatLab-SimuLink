//
// File: XsensWebSocketAngleRefBandTest_v4_5_1.cpp
//
// Code generated for Simulink model 'XsensWebSocketAngleRefBandTest_v4_5_1'.
//
// Model version                  : 1.88
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Tue Jul 18 14:05:15 2017
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "XsensWebSocketAngleRefBandTest_v4_5_1.h"
#include "XsensWebSocketAngleRefBandTest_v4_5_1_private.h"
#include "XsensWebSocketAngleRefBandTest_v4_5_1_dt.h"

// Block signals (auto storage)
B_XsensWebSocketAngleRefBandT_T XsensWebSocketAngleRefBandTes_B;

// Continuous states
X_XsensWebSocketAngleRefBandT_T XsensWebSocketAngleRefBandTes_X;

// Block states (auto storage)
DW_XsensWebSocketAngleRefBand_T XsensWebSocketAngleRefBandTe_DW;

// Real-time model
RT_MODEL_XsensWebSocketAngleR_T XsensWebSocketAngleRefBandTe_M_;
RT_MODEL_XsensWebSocketAngleR_T *const XsensWebSocketAngleRefBandTe_M =
  &XsensWebSocketAngleRefBandTe_M_;

//
// Writes out MAT-file header.  Returns success or failure.
// Returns:
//      0 - success
//      1 - failure
//
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      // end rt_WriteMat4FileHeader

//
// This function updates continuous states using the ODE3 fixed-step
// solver algorithm
//
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  // Solver Matrices
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 12;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  XsensWebSocketAngleRefBandTest_v4_5_1_derivatives();

  // f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*));
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  XsensWebSocketAngleRefBandTest_v4_5_1_step0();
  XsensWebSocketAngleRefBandTest_v4_5_1_derivatives();

  // f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*));
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  XsensWebSocketAngleRefBandTest_v4_5_1_step0();
  XsensWebSocketAngleRefBandTest_v4_5_1_derivatives();

  // tnew = t + hA(3);
  // ynew = y + f*hB(:,3);
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

// Model step function for TID0
void XsensWebSocketAngleRefBandTest_v4_5_1_step0(void) // Sample time: [0.0s, 0.0s] 
{
  // local block i/o variables
  real_T rtb_XsensIMUs_o1[160];
  real_T rtb_XsensIMUs_o2[160];
  real_T rtb_XsensIMUs_o3[160];
  real_T rtb_XsensIMUs_o4[160];
  real_T rtb_XsensIMUs_o5[160];
  real_T rtb_XsensIMUs_o6[160];
  real_T rtb_XsensIMUs_o7[160];
  real_T rtb_XsensIMUs_o8[160];
  real_T rtb_XsensIMUs_o9[160];
  real_T rtb_XsensIMUs_o10[160];
  real_T rtb_time;
  real_T factor;
  real_T diff;
  real_T rtb_TransferFcn;
  real_T rtb_TransferFcn1;
  real_T rtb_Add[2];
  real_T rtb_Switch1_n_idx_0;
  real_T rtb_Switch1_n_idx_1;
  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    // set solver stop time
    if (!(XsensWebSocketAngleRefBandTe_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                            ((XsensWebSocketAngleRefBandTe_M->Timing.clockTickH0
        + 1) * XsensWebSocketAngleRefBandTe_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                            ((XsensWebSocketAngleRefBandTe_M->Timing.clockTick0
        + 1) * XsensWebSocketAngleRefBandTe_M->Timing.stepSize0 +
        XsensWebSocketAngleRefBandTe_M->Timing.clockTickH0 *
        XsensWebSocketAngleRefBandTe_M->Timing.stepSize0 * 4294967296.0));
    }

    // Update the flag to indicate when data transfers from
    //   Sample time: [0.0s, 0.0s] to Sample time: [0.04s, 0.0s]
    (XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID0_2)++;
    if ((XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID0_2) > 3) {
      XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID0_2 = 0;
    }

    // Update the flag to indicate when data transfers from
    //   Sample time: [0.01s, 0.0s] to Sample time: [0.04s, 0.0s]
    (XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2)++;
    if ((XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2) > 3) {
      XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2 = 0;
    }
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    XsensWebSocketAngleRefBandTe_M->Timing.t[0] = rtsiGetT
      (&XsensWebSocketAngleRefBandTe_M->solverInfo);
  }

  // RateTransition: '<Root>/Rate Transition1' incorporates:
  //   S-Function (ex_sfun_sci_xsens): '<Root>/Xsens IMUs'

  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    // RateTransition: '<Root>/Rate Transition6' incorporates:
    //   RateTransition: '<Root>/Rate Transition'

    if (XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2 == 1) {
      XsensWebSocketAngleRefBandTes_B.RateTransition1 =
        XsensWebSocketAngleRefBandTe_DW.RateTransition1_Buffer0;
      XsensWebSocketAngleRefBandTes_B.RateTransition6[0] =
        XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[0];
      XsensWebSocketAngleRefBandTes_B.RateTransition6[1] =
        XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[1];
      XsensWebSocketAngleRefBandTes_B.RateTransition6[2] =
        XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[2];
      XsensWebSocketAngleRefBandTes_B.RateTransition =
        XsensWebSocketAngleRefBandTe_DW.RateTransition_Buffer0;
    }

    // End of RateTransition: '<Root>/Rate Transition6'

    // DataTypeConversion: '<Root>/Data Type Conversion'
    XsensWebSocketAngleRefBandTes_B.DataTypeConversion =
      XsensWebSocketAngleRefBandTes_B.RateTransition;

    // SignalConversion: '<Root>/TmpSignal ConversionAtTo FileInport1'
    XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[0] =
      XsensWebSocketAngleRefBandTes_B.RateTransition1;
    XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[1] =
      XsensWebSocketAngleRefBandTes_B.RateTransition6[0];
    XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[2] =
      XsensWebSocketAngleRefBandTes_B.RateTransition6[1];
    XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[3] =
      XsensWebSocketAngleRefBandTes_B.RateTransition6[2];
    XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[4] =
      XsensWebSocketAngleRefBandTes_B.DataTypeConversion;

    // Stop: '<Root>/Stop Simulation' incorporates:
    //   Constant: '<S1>/Constant'
    //   RelationalOperator: '<S1>/Compare'

    if (XsensWebSocketAngleRefBandTes_B.RateTransition1 ==
        XsensWebSocketAngleRefBandTes_P.CompareToConstant_const) {
      rtmSetStopRequested(XsensWebSocketAngleRefBandTe_M, 1);
    }

    // End of Stop: '<Root>/Stop Simulation'

    // ToFile: '<Root>/To File'
    if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
      {
        if (!(++XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Decimation % 1) &&
            (XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Count*6)+1 < 100000000
            ) {
          FILE *fp = (FILE *)
            XsensWebSocketAngleRefBandTe_DW.ToFile_PWORK.FilePtr;
          if (fp != (NULL)) {
            real_T u[6];
            XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Decimation = 0;
            u[0] = (((XsensWebSocketAngleRefBandTe_M->Timing.clockTick1+
                      XsensWebSocketAngleRefBandTe_M->Timing.clockTickH1*
                      4294967296.0)) * 0.01);
            u[1] =
              XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[0];
            u[2] =
              XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[1];
            u[3] =
              XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[2];
            u[4] =
              XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[3];
            u[5] =
              XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo[4];
            if (fwrite(u, sizeof(real_T), 6, fp) != 6) {
              rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                                "Error writing to MAT-file webSocketTestBand.mat");
              return;
            }

            if (((++XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Count)*6)+1 >=
                100000000) {
              (void)fprintf(stdout,
                            "*** The ToFile block will stop logging data before\n"
                            "    the simulation has ended, because it has reached\n"
                            "    the maximum number of elements (100000000)\n"
                            "    allowed in MAT-file webSocketTestBand.mat.\n");
            }
          }
        }
      }
    }

    // S-Function (ex_sfun_sci_xsens): '<Root>/Xsens IMUs'
    output_xsens( &XsensWebSocketAngleRefBandTe_DW.XsensIMUs_PWORK,
                 &rtb_XsensIMUs_o1[0], &rtb_XsensIMUs_o2[0], &rtb_XsensIMUs_o3[0],
                 &rtb_XsensIMUs_o4[0], &rtb_XsensIMUs_o5[0], &rtb_XsensIMUs_o6[0],
                 &rtb_XsensIMUs_o7[0], &rtb_XsensIMUs_o8[0], &rtb_XsensIMUs_o9[0],
                 &rtb_XsensIMUs_o10[0]);

    // MATLAB Function: '<S2>/Extractor' incorporates:
    //   S-Function (ex_sfun_sci_xsens): '<Root>/Xsens IMUs'

    // MATLAB Function 'Extract/Extractor': '<S8>:1'
    // '<S8>:1:4'
    // '<S8>:1:6'
    // '<S8>:1:7'
    // '<S8>:1:8'
    // '<S8>:1:9'
    // '<S8>:1:10'
    XsensWebSocketAngleRefBandTes_B.q[0] = rtb_XsensIMUs_o1[10];
    XsensWebSocketAngleRefBandTes_B.q[1] = rtb_XsensIMUs_o1[11];
    XsensWebSocketAngleRefBandTes_B.q[2] = rtb_XsensIMUs_o1[12];
    XsensWebSocketAngleRefBandTes_B.q[3] = rtb_XsensIMUs_o1[13];

    // '<S8>:1:11'
    // '<S8>:1:22'
    factor = 1.0;

    // '<S8>:1:24'
    diff = fabs(rtb_XsensIMUs_o1[0] -
                XsensWebSocketAngleRefBandTe_DW.lastSampleNumber);
    if (diff >= 1.0) {
      // '<S8>:1:26'
      // '<S8>:1:27'
      factor = diff;
    }

    if (diff == 0.0) {
      // '<S8>:1:29'
      // '<S8>:1:30'
      factor = XsensWebSocketAngleRefBandTe_DW.lastFactor;
    }

    // '<S8>:1:33'
    XsensWebSocketAngleRefBandTe_DW.lastFactor = factor;

    // '<S8>:1:34'
    XsensWebSocketAngleRefBandTe_DW.lastSampleNumber = rtb_XsensIMUs_o1[0];

    // End of MATLAB Function: '<S2>/Extractor'
  }

  // End of RateTransition: '<Root>/Rate Transition1'

  // TransferFcn: '<S6>/Transfer Fcn'
  rtb_TransferFcn = XsensWebSocketAngleRefBandTes_P.TransferFcn_C[0] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[0] +
    XsensWebSocketAngleRefBandTes_P.TransferFcn_C[1] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[1];

  // Saturate: '<S6>/Saturation'
  if (rtb_TransferFcn > XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat) {
    factor = XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat;
  } else if (rtb_TransferFcn <
             XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat) {
    factor = XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat;
  } else {
    factor = rtb_TransferFcn;
  }

  // End of Saturate: '<S6>/Saturation'

  // TransferFcn: '<S6>/Transfer Fcn1'
  rtb_TransferFcn1 = XsensWebSocketAngleRefBandTes_P.TransferFcn1_C[0] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[0] +
    XsensWebSocketAngleRefBandTes_P.TransferFcn1_C[1] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[1];

  // Saturate: '<S6>/Saturation1'
  if (rtb_TransferFcn1 > XsensWebSocketAngleRefBandTes_P.Saturation1_UpperSat) {
    diff = XsensWebSocketAngleRefBandTes_P.Saturation1_UpperSat;
  } else if (rtb_TransferFcn1 <
             XsensWebSocketAngleRefBandTes_P.Saturation1_LowerSat) {
    diff = XsensWebSocketAngleRefBandTes_P.Saturation1_LowerSat;
  } else {
    diff = rtb_TransferFcn1;
  }

  // End of Saturate: '<S6>/Saturation1'

  // RateTransition: '<Root>/Rate Transition7'
  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M) &&
      (XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2 == 1)) {
    XsensWebSocketAngleRefBandTes_B.r[0] =
      XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0[0];
    XsensWebSocketAngleRefBandTes_B.r[1] =
      XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0[1];
  }

  // End of RateTransition: '<Root>/Rate Transition7'

  // Sum: '<Root>/Add'
  rtb_Add[0] = XsensWebSocketAngleRefBandTes_B.r[0] - factor;
  rtb_Add[1] = XsensWebSocketAngleRefBandTes_B.r[1] - diff;
  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    // DigitalClock: '<Root>/Digital Clock'
    rtb_time = (((XsensWebSocketAngleRefBandTe_M->Timing.clockTick1+
                  XsensWebSocketAngleRefBandTe_M->Timing.clockTickH1*
                  4294967296.0)) * 0.01);

    // MATLAB Function: '<Root>/MATLAB Function'
    // MATLAB Function 'MATLAB Function': '<S3>:1'
    // x-EinheitsVektor wird zu Quaternion mit erster Eintrag null
    // '<S3>:1:4'
    // Calculate product of two quaternions
    // '<S3>:1:5'
    // '<S3>:1:6'
    // Calculate product of two quaternions
    // '<S3>:1:7'
    //  remove leading zero again
    // '<S3>:1:8'
    //  90°-angle_between_xtrans_and_[0 0 1]
    // y-EinheitsVektor wird zu Quaternion mit erster Eintrag null
    // '<S3>:1:11'
    // Calculate product of two quaternions
    // '<S3>:1:12'
    // '<S3>:1:13'
    // Calculate product of two quaternions
    // '<S3>:1:14'
    //  remove leading zero again
    // '<S3>:1:15'
    //  90°-angle_between_xtrans_and_[0 0 1]
    // '<S3>:1:17'
    XsensWebSocketAngleRefBandTes_B.u_n[0] = 1.5707963267948966 - acos((((((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[3] - XsensWebSocketAngleRefBandTes_B.q[2])
      + 0.0 * XsensWebSocketAngleRefBandTes_B.q[1]) + 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[0]) * XsensWebSocketAngleRefBandTes_B.q
      [0] - (((0.0 * XsensWebSocketAngleRefBandTes_B.q[2] +
               XsensWebSocketAngleRefBandTes_B.q[3]) + 0.0 *
              XsensWebSocketAngleRefBandTes_B.q[0]) - 0.0 *
             XsensWebSocketAngleRefBandTes_B.q[1]) *
      -XsensWebSocketAngleRefBandTes_B.q[1]) + (((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[1] + XsensWebSocketAngleRefBandTes_B.q[0])
      - 0.0 * XsensWebSocketAngleRefBandTes_B.q[3]) + 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[2]) *
      -XsensWebSocketAngleRefBandTes_B.q[2]) + (((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[0] - XsensWebSocketAngleRefBandTes_B.q[1])
      - 0.0 * XsensWebSocketAngleRefBandTes_B.q[2]) - 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[3]) *
      -XsensWebSocketAngleRefBandTes_B.q[3]);
    XsensWebSocketAngleRefBandTes_B.u_n[1] = 1.5707963267948966 - acos((((((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[3] - 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[2]) + XsensWebSocketAngleRefBandTes_B.q
      [1]) + 0.0 * XsensWebSocketAngleRefBandTes_B.q[0]) *
      XsensWebSocketAngleRefBandTes_B.q[0] - (((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[2] + 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[3]) + XsensWebSocketAngleRefBandTes_B.q
      [0]) - 0.0 * XsensWebSocketAngleRefBandTes_B.q[1]) *
      -XsensWebSocketAngleRefBandTes_B.q[1]) + (((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[1] + 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[0]) - XsensWebSocketAngleRefBandTes_B.q
      [3]) + 0.0 * XsensWebSocketAngleRefBandTes_B.q[2]) *
      -XsensWebSocketAngleRefBandTes_B.q[2]) + (((0.0 *
      XsensWebSocketAngleRefBandTes_B.q[0] - 0.0 *
      XsensWebSocketAngleRefBandTes_B.q[1]) - XsensWebSocketAngleRefBandTes_B.q
      [2]) - 0.0 * XsensWebSocketAngleRefBandTes_B.q[3]) *
      -XsensWebSocketAngleRefBandTes_B.q[3]);

    // Constant: '<S4>/Constant'
    XsensWebSocketAngleRefBandTes_B.Constant[0] =
      XsensWebSocketAngleRefBandTes_P.Constant_Value[0];
    XsensWebSocketAngleRefBandTes_B.Constant[1] =
      XsensWebSocketAngleRefBandTes_P.Constant_Value[1];

    // RateTransition: '<Root>/Rate Transition8'
    if (XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2 == 1) {
      XsensWebSocketAngleRefBandTes_B.RateTransition8 =
        XsensWebSocketAngleRefBandTe_DW.RateTransition8_Buffer0;
    }

    // End of RateTransition: '<Root>/Rate Transition8'
  }

  // Switch: '<S4>/Switch'
  if (XsensWebSocketAngleRefBandTes_B.RateTransition8 >=
      XsensWebSocketAngleRefBandTes_P.Switch_Threshold_i) {
    rtb_Switch1_n_idx_0 = XsensWebSocketAngleRefBandTes_B.Constant[0];
    rtb_Switch1_n_idx_1 = XsensWebSocketAngleRefBandTes_B.Constant[1];
  } else {
    rtb_Switch1_n_idx_0 = rtb_Add[0];
    rtb_Switch1_n_idx_1 = rtb_Add[1];
  }

  // End of Switch: '<S4>/Switch'

  // Product: '<S4>/Product1'
  XsensWebSocketAngleRefBandTes_B.Product1 = rtb_Switch1_n_idx_0 *
    XsensWebSocketAngleRefBandTes_B.RateTransition6[2];

  // Product: '<S4>/Product4'
  XsensWebSocketAngleRefBandTes_B.Product4 = rtb_Switch1_n_idx_1 *
    XsensWebSocketAngleRefBandTes_B.RateTransition6[2];

  // Product: '<S4>/Product'
  XsensWebSocketAngleRefBandTes_B.Product = rtb_Switch1_n_idx_0 *
    XsensWebSocketAngleRefBandTes_B.RateTransition6[1];

  // Product: '<S4>/Product3'
  XsensWebSocketAngleRefBandTes_B.Product3 = rtb_Switch1_n_idx_1 *
    XsensWebSocketAngleRefBandTes_B.RateTransition6[1];

  // RateTransition: '<Root>/Rate Transition11' incorporates:
  //   Constant: '<S5>/Constant'

  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    XsensWebSocketAngleRefBandTes_B.Constant_a[0] =
      XsensWebSocketAngleRefBandTes_P.Constant_Value_b[0];
    XsensWebSocketAngleRefBandTes_B.Constant_a[1] =
      XsensWebSocketAngleRefBandTes_P.Constant_Value_b[1];

    // RateTransition: '<Root>/Rate Transition2' incorporates:
    //   Constant: '<S5>/Constant'
    //   RateTransition: '<Root>/Rate Transition3'

    if (XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID1_2 == 1) {
      XsensWebSocketAngleRefBandTes_B.RateTransition11 =
        XsensWebSocketAngleRefBandTe_DW.RateTransition11_Buffer0;
      XsensWebSocketAngleRefBandTes_B.time = rtb_time;
      XsensWebSocketAngleRefBandTes_B.quat[0] =
        XsensWebSocketAngleRefBandTes_B.q[0];
      XsensWebSocketAngleRefBandTes_B.quat[1] =
        XsensWebSocketAngleRefBandTes_B.q[1];
      XsensWebSocketAngleRefBandTes_B.quat[2] =
        XsensWebSocketAngleRefBandTes_B.q[2];
      XsensWebSocketAngleRefBandTes_B.quat[3] =
        XsensWebSocketAngleRefBandTes_B.q[3];
    }

    // End of RateTransition: '<Root>/Rate Transition2'
  }

  // End of RateTransition: '<Root>/Rate Transition11'

  // Switch: '<S5>/Switch'
  if (XsensWebSocketAngleRefBandTes_B.RateTransition8 >=
      XsensWebSocketAngleRefBandTes_P.Switch_Threshold_d) {
    XsensWebSocketAngleRefBandTes_B.Switch[0] =
      XsensWebSocketAngleRefBandTes_B.Constant_a[0];
    XsensWebSocketAngleRefBandTes_B.Switch[1] =
      XsensWebSocketAngleRefBandTes_B.Constant_a[1];
  } else {
    XsensWebSocketAngleRefBandTes_B.Switch[0] = rtb_Add[0];
    XsensWebSocketAngleRefBandTes_B.Switch[1] = rtb_Add[1];
  }

  // End of Switch: '<S5>/Switch'

  // Switch: '<Root>/Switch' incorporates:
  //   Switch: '<Root>/Switch1'

  if (XsensWebSocketAngleRefBandTes_B.RateTransition8 >
      XsensWebSocketAngleRefBandTes_P.Switch_Threshold_p) {
    rtb_Switch1_n_idx_0 = XsensWebSocketAngleRefBandTes_B.u_n[0];
    rtb_Switch1_n_idx_1 = XsensWebSocketAngleRefBandTes_B.u_n[1];
  } else if (XsensWebSocketAngleRefBandTes_B.RateTransition11 >
             XsensWebSocketAngleRefBandTes_P.Switch1_Threshold) {
    // Switch: '<Root>/Switch1' incorporates:
    //   Integrator: '<S5>/Integrator'
    //   Integrator: '<S5>/Integrator1'
    //   Sum: '<S5>/Add'
    //   Sum: '<S5>/Add1'
    //   TransferFcn: '<S5>/Transfer Fcn1'
    //   TransferFcn: '<S5>/Transfer Fcn2'

    rtb_Switch1_n_idx_0 = (XsensWebSocketAngleRefBandTes_P.TransferFcn2_C_c *
      XsensWebSocketAngleRefBandTes_X.TransferFcn2_CSTATE_d +
      XsensWebSocketAngleRefBandTes_P.TransferFcn2_D_c *
      XsensWebSocketAngleRefBandTes_B.Switch[0]) +
      (XsensWebSocketAngleRefBandTes_B.Switch[0] +
       XsensWebSocketAngleRefBandTes_X.Integrator_CSTATE_e);
    rtb_Switch1_n_idx_1 = (XsensWebSocketAngleRefBandTes_P.TransferFcn1_C_n *
      XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE_e +
      XsensWebSocketAngleRefBandTes_P.TransferFcn1_D_o *
      XsensWebSocketAngleRefBandTes_B.Switch[1]) +
      (XsensWebSocketAngleRefBandTes_B.Switch[1] +
       XsensWebSocketAngleRefBandTes_X.Integrator1_CSTATE_g);
  } else {
    // Switch: '<Root>/Switch1' incorporates:
    //   Integrator: '<S4>/Integrator'
    //   Integrator: '<S4>/Integrator1'
    //   Product: '<S4>/Product2'
    //   Product: '<S4>/Product5'
    //   Sum: '<S4>/Add'
    //   Sum: '<S4>/Add1'
    //   TransferFcn: '<S4>/Transfer Fcn1'
    //   TransferFcn: '<S4>/Transfer Fcn2'

    rtb_Switch1_n_idx_0 = (rtb_Switch1_n_idx_0 *
      XsensWebSocketAngleRefBandTes_B.RateTransition6[0] +
      XsensWebSocketAngleRefBandTes_X.Integrator_CSTATE) +
      (XsensWebSocketAngleRefBandTes_P.TransferFcn2_C *
       XsensWebSocketAngleRefBandTes_X.TransferFcn2_CSTATE +
       XsensWebSocketAngleRefBandTes_P.TransferFcn2_D *
       XsensWebSocketAngleRefBandTes_B.Product1);
    rtb_Switch1_n_idx_1 = (rtb_Switch1_n_idx_1 *
      XsensWebSocketAngleRefBandTes_B.RateTransition6[0] +
      XsensWebSocketAngleRefBandTes_X.Integrator1_CSTATE) +
      (XsensWebSocketAngleRefBandTes_P.TransferFcn1_C_m *
       XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE_f +
       XsensWebSocketAngleRefBandTes_P.TransferFcn1_D *
       XsensWebSocketAngleRefBandTes_B.Product4);
  }

  // End of Switch: '<Root>/Switch'

  // Saturate: '<Root>/Saturation'
  if (rtb_Switch1_n_idx_0 >
      XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat_n) {
    rtb_Switch1_n_idx_0 = XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat_n;
  } else {
    if (rtb_Switch1_n_idx_0 <
        XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat_e) {
      rtb_Switch1_n_idx_0 =
        XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat_e;
    }
  }

  if (rtb_Switch1_n_idx_1 >
      XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat_n) {
    rtb_Switch1_n_idx_1 = XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat_n;
  } else {
    if (rtb_Switch1_n_idx_1 <
        XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat_e) {
      rtb_Switch1_n_idx_1 =
        XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat_e;
    }
  }

  // End of Saturate: '<Root>/Saturation'

  // RateTransition: '<Root>/Rate Transition4'
  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M) &&
      XsensWebSocketAngleRefBandTe_M->Timing.RateInteraction.TID0_2 == 1) {
    // RateTransition: '<Root>/Rate Transition5'
    XsensWebSocketAngleRefBandTes_B.y[0] = factor;
    XsensWebSocketAngleRefBandTes_B.y[1] = diff;
    XsensWebSocketAngleRefBandTes_B.u[0] = rtb_Switch1_n_idx_0;

    // RateTransition: '<Root>/Rate Transition9'
    XsensWebSocketAngleRefBandTes_B.error[0] = rtb_Add[0];
    XsensWebSocketAngleRefBandTes_B.u[1] = rtb_Switch1_n_idx_1;

    // RateTransition: '<Root>/Rate Transition9'
    XsensWebSocketAngleRefBandTes_B.error[1] = rtb_Add[1];
  }

  // End of RateTransition: '<Root>/Rate Transition4'
  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    // Constant: '<S6>/Constant'
    XsensWebSocketAngleRefBandTes_B.Constant_a3 =
      XsensWebSocketAngleRefBandTes_P.Constant_Value_f;

    // Constant: '<S6>/Constant1'
    XsensWebSocketAngleRefBandTes_B.Constant1 =
      XsensWebSocketAngleRefBandTes_P.Constant1_Value;
  }

  // Switch: '<S6>/Switch4' incorporates:
  //   MinMax: '<S6>/MinMax2'
  //   Switch: '<S6>/Switch3'

  if (rtb_TransferFcn >= XsensWebSocketAngleRefBandTes_P.Switch4_Threshold) {
    // Switch: '<S6>/Switch1'
    if (rtb_TransferFcn >= XsensWebSocketAngleRefBandTes_P.Switch1_Threshold_j)
    {
      // MinMax: '<S6>/MinMax'
      if ((XsensWebSocketAngleRefBandTes_B.Constant_a3 <= rtb_Switch1_n_idx_0) ||
          rtIsNaN(rtb_Switch1_n_idx_0)) {
        XsensWebSocketAngleRefBandTes_B.Switch4 =
          XsensWebSocketAngleRefBandTes_B.Constant_a3;
      } else {
        XsensWebSocketAngleRefBandTes_B.Switch4 = rtb_Switch1_n_idx_0;
      }

      // End of MinMax: '<S6>/MinMax'
    } else {
      XsensWebSocketAngleRefBandTes_B.Switch4 = rtb_Switch1_n_idx_0;
    }

    // End of Switch: '<S6>/Switch1'
  } else if (rtb_TransferFcn >=
             XsensWebSocketAngleRefBandTes_P.Switch3_Threshold) {
    // Switch: '<S6>/Switch3'
    XsensWebSocketAngleRefBandTes_B.Switch4 = rtb_Switch1_n_idx_0;
  } else if ((XsensWebSocketAngleRefBandTes_B.Constant1 >= rtb_Switch1_n_idx_0) ||
             rtIsNaN(rtb_Switch1_n_idx_0)) {
    // MinMax: '<S6>/MinMax2' incorporates:
    //   Switch: '<S6>/Switch3'

    XsensWebSocketAngleRefBandTes_B.Switch4 =
      XsensWebSocketAngleRefBandTes_B.Constant1;
  } else {
    // Switch: '<S6>/Switch3' incorporates:
    //   MinMax: '<S6>/MinMax2'

    XsensWebSocketAngleRefBandTes_B.Switch4 = rtb_Switch1_n_idx_0;
  }

  // End of Switch: '<S6>/Switch4'

  // Switch: '<S6>/Switch5' incorporates:
  //   MinMax: '<S6>/MinMax3'
  //   Switch: '<S6>/Switch2'

  if (rtb_TransferFcn1 >= XsensWebSocketAngleRefBandTes_P.Switch5_Threshold) {
    // Switch: '<S6>/Switch'
    if (rtb_TransferFcn1 >= XsensWebSocketAngleRefBandTes_P.Switch_Threshold) {
      // MinMax: '<S6>/MinMax1'
      if ((XsensWebSocketAngleRefBandTes_B.Constant_a3 <= rtb_Switch1_n_idx_1) ||
          rtIsNaN(rtb_Switch1_n_idx_1)) {
        XsensWebSocketAngleRefBandTes_B.Switch5 =
          XsensWebSocketAngleRefBandTes_B.Constant_a3;
      } else {
        XsensWebSocketAngleRefBandTes_B.Switch5 = rtb_Switch1_n_idx_1;
      }

      // End of MinMax: '<S6>/MinMax1'
    } else {
      XsensWebSocketAngleRefBandTes_B.Switch5 = rtb_Switch1_n_idx_1;
    }

    // End of Switch: '<S6>/Switch'
  } else if (rtb_TransferFcn1 >=
             XsensWebSocketAngleRefBandTes_P.Switch2_Threshold) {
    // Switch: '<S6>/Switch2'
    XsensWebSocketAngleRefBandTes_B.Switch5 = rtb_Switch1_n_idx_1;
  } else if ((XsensWebSocketAngleRefBandTes_B.Constant1 >= rtb_Switch1_n_idx_1) ||
             rtIsNaN(rtb_Switch1_n_idx_1)) {
    // MinMax: '<S6>/MinMax3' incorporates:
    //   Switch: '<S6>/Switch2'

    XsensWebSocketAngleRefBandTes_B.Switch5 =
      XsensWebSocketAngleRefBandTes_B.Constant1;
  } else {
    // Switch: '<S6>/Switch2' incorporates:
    //   MinMax: '<S6>/MinMax3'

    XsensWebSocketAngleRefBandTes_B.Switch5 = rtb_Switch1_n_idx_1;
  }

  // End of Switch: '<S6>/Switch5'
  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    // External mode
    rtExtModeUploadCheckTrigger(3);
    rtExtModeUpload(1, XsensWebSocketAngleRefBandTe_M->Timing.t[0]);
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep(XsensWebSocketAngleRefBandTe_M)) {
    // signal main to stop simulation
    {                                  // Sample time: [0.0s, 0.0s]
      if ((rtmGetTFinal(XsensWebSocketAngleRefBandTe_M)!=-1) &&
          !((rtmGetTFinal(XsensWebSocketAngleRefBandTe_M)-
             (((XsensWebSocketAngleRefBandTe_M->Timing.clockTick1+
                XsensWebSocketAngleRefBandTe_M->Timing.clockTickH1* 4294967296.0))
              * 0.01)) > (((XsensWebSocketAngleRefBandTe_M->Timing.clockTick1+
                            XsensWebSocketAngleRefBandTe_M->Timing.clockTickH1*
                            4294967296.0)) * 0.01) * (DBL_EPSILON))) {
        rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M, "Simulation finished");
      }

      if (rtmGetStopRequested(XsensWebSocketAngleRefBandTe_M)) {
        rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&XsensWebSocketAngleRefBandTe_M->solverInfo);

    // Update absolute time
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.
    //  Timer of this task consists of two 32 bit unsigned integers.
    //  The two integers represent the low bits Timing.clockTick0 and the high bits
    //  Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.

    if (!(++XsensWebSocketAngleRefBandTe_M->Timing.clockTick0)) {
      ++XsensWebSocketAngleRefBandTe_M->Timing.clockTickH0;
    }

    XsensWebSocketAngleRefBandTe_M->Timing.t[0] = rtsiGetSolverStopTime
      (&XsensWebSocketAngleRefBandTe_M->solverInfo);

    // Update absolute time
    // The "clockTick1" counts the number of times the code of this task has
    //  been executed. The resolution of this integer timer is 0.01, which is the step size
    //  of the task. Size of "clockTick1" ensures timer will not overflow during the
    //  application lifespan selected.
    //  Timer of this task consists of two 32 bit unsigned integers.
    //  The two integers represent the low bits Timing.clockTick1 and the high bits
    //  Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.

    XsensWebSocketAngleRefBandTe_M->Timing.clockTick1++;
    if (!XsensWebSocketAngleRefBandTe_M->Timing.clockTick1) {
      XsensWebSocketAngleRefBandTe_M->Timing.clockTickH1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void XsensWebSocketAngleRefBandTest_v4_5_1_derivatives(void)
{
  XDot_XsensWebSocketAngleRefBa_T *_rtXdot;
  _rtXdot = ((XDot_XsensWebSocketAngleRefBa_T *)
             XsensWebSocketAngleRefBandTe_M->ModelData.derivs);

  // Derivatives for TransferFcn: '<S6>/Transfer Fcn'
  _rtXdot->TransferFcn_CSTATE[0] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn_A[0] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[0];
  _rtXdot->TransferFcn_CSTATE[1] = 0.0;
  _rtXdot->TransferFcn_CSTATE[0] +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn_A[1] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[1];
  _rtXdot->TransferFcn_CSTATE[1] +=
    XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[0];
  _rtXdot->TransferFcn_CSTATE[0] += XsensWebSocketAngleRefBandTes_B.Switch4;

  // Derivatives for TransferFcn: '<S6>/Transfer Fcn1'
  _rtXdot->TransferFcn1_CSTATE[0] = 0.0;
  _rtXdot->TransferFcn1_CSTATE[0] +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn1_A[0] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[0];
  _rtXdot->TransferFcn1_CSTATE[1] = 0.0;
  _rtXdot->TransferFcn1_CSTATE[0] +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn1_A[1] *
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[1];
  _rtXdot->TransferFcn1_CSTATE[1] +=
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[0];
  _rtXdot->TransferFcn1_CSTATE[0] += XsensWebSocketAngleRefBandTes_B.Switch5;

  // Derivatives for Integrator: '<S4>/Integrator'
  _rtXdot->Integrator_CSTATE = XsensWebSocketAngleRefBandTes_B.Product;

  // Derivatives for TransferFcn: '<S4>/Transfer Fcn2'
  _rtXdot->TransferFcn2_CSTATE = 0.0;
  _rtXdot->TransferFcn2_CSTATE += XsensWebSocketAngleRefBandTes_P.TransferFcn2_A
    * XsensWebSocketAngleRefBandTes_X.TransferFcn2_CSTATE;
  _rtXdot->TransferFcn2_CSTATE += XsensWebSocketAngleRefBandTes_B.Product1;

  // Derivatives for Integrator: '<S4>/Integrator1'
  _rtXdot->Integrator1_CSTATE = XsensWebSocketAngleRefBandTes_B.Product3;

  // Derivatives for TransferFcn: '<S4>/Transfer Fcn1'
  _rtXdot->TransferFcn1_CSTATE_f = 0.0;
  _rtXdot->TransferFcn1_CSTATE_f +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn1_A_g *
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE_f;
  _rtXdot->TransferFcn1_CSTATE_f += XsensWebSocketAngleRefBandTes_B.Product4;

  // Derivatives for Integrator: '<S5>/Integrator'
  _rtXdot->Integrator_CSTATE_e = XsensWebSocketAngleRefBandTes_B.Switch[0];

  // Derivatives for TransferFcn: '<S5>/Transfer Fcn2'
  _rtXdot->TransferFcn2_CSTATE_d = 0.0;
  _rtXdot->TransferFcn2_CSTATE_d +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn2_A_l *
    XsensWebSocketAngleRefBandTes_X.TransferFcn2_CSTATE_d;
  _rtXdot->TransferFcn2_CSTATE_d += XsensWebSocketAngleRefBandTes_B.Switch[0];

  // Derivatives for Integrator: '<S5>/Integrator1'
  _rtXdot->Integrator1_CSTATE_g = XsensWebSocketAngleRefBandTes_B.Switch[1];

  // Derivatives for TransferFcn: '<S5>/Transfer Fcn1'
  _rtXdot->TransferFcn1_CSTATE_e = 0.0;
  _rtXdot->TransferFcn1_CSTATE_e +=
    XsensWebSocketAngleRefBandTes_P.TransferFcn1_A_b *
    XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE_e;
  _rtXdot->TransferFcn1_CSTATE_e += XsensWebSocketAngleRefBandTes_B.Switch[1];
}

// Model step function for TID2
void XsensWebSocketAngleRefBandTest_v4_5_1_step2(void) // Sample time: [0.04s, 0.0s] 
{
  // local block i/o variables
  real_T rtb_WebSocketServerSFunction_o1[8];
  real_T rtb_TmpSignalConversionAtWebSoc[11];
  int32_T rtb_WebSocketServerSFunction_o2;

  // SignalConversion: '<S7>/TmpSignal ConversionAtWebSocketServer SFunctionInport1' 
  rtb_TmpSignalConversionAtWebSoc[0] = XsensWebSocketAngleRefBandTes_B.time;
  rtb_TmpSignalConversionAtWebSoc[1] = XsensWebSocketAngleRefBandTes_B.quat[0];
  rtb_TmpSignalConversionAtWebSoc[2] = XsensWebSocketAngleRefBandTes_B.quat[1];
  rtb_TmpSignalConversionAtWebSoc[3] = XsensWebSocketAngleRefBandTes_B.quat[2];
  rtb_TmpSignalConversionAtWebSoc[4] = XsensWebSocketAngleRefBandTes_B.quat[3];
  rtb_TmpSignalConversionAtWebSoc[5] = XsensWebSocketAngleRefBandTes_B.u[0];
  rtb_TmpSignalConversionAtWebSoc[7] = XsensWebSocketAngleRefBandTes_B.y[0];
  rtb_TmpSignalConversionAtWebSoc[9] = XsensWebSocketAngleRefBandTes_B.error[0];
  rtb_TmpSignalConversionAtWebSoc[6] = XsensWebSocketAngleRefBandTes_B.u[1];
  rtb_TmpSignalConversionAtWebSoc[8] = XsensWebSocketAngleRefBandTes_B.y[1];
  rtb_TmpSignalConversionAtWebSoc[10] = XsensWebSocketAngleRefBandTes_B.error[1];

  // S-Function (web_socket_server): '<S7>/WebSocketServer SFunction'
  output_webSocketServer
    ( &XsensWebSocketAngleRefBandTe_DW.WebSocketServerSFunction_PWORK, (real_T*)
     &rtb_TmpSignalConversionAtWebSoc[0], &rtb_WebSocketServerSFunction_o1[0],
     &rtb_WebSocketServerSFunction_o2);

  // Update for RateTransition: '<Root>/Rate Transition1'
  XsensWebSocketAngleRefBandTe_DW.RateTransition1_Buffer0 =
    rtb_WebSocketServerSFunction_o1[0];

  // Update for RateTransition: '<Root>/Rate Transition6'
  XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[0] =
    rtb_WebSocketServerSFunction_o1[1];
  XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[1] =
    rtb_WebSocketServerSFunction_o1[2];
  XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[2] =
    rtb_WebSocketServerSFunction_o1[3];

  // Update for RateTransition: '<Root>/Rate Transition'
  XsensWebSocketAngleRefBandTe_DW.RateTransition_Buffer0 =
    rtb_WebSocketServerSFunction_o2;

  // Update for RateTransition: '<Root>/Rate Transition7'
  XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0[0] =
    rtb_WebSocketServerSFunction_o1[4];
  XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0[1] =
    rtb_WebSocketServerSFunction_o1[5];

  // Update for RateTransition: '<Root>/Rate Transition8'
  XsensWebSocketAngleRefBandTe_DW.RateTransition8_Buffer0 =
    rtb_WebSocketServerSFunction_o1[6];

  // Update for RateTransition: '<Root>/Rate Transition11'
  XsensWebSocketAngleRefBandTe_DW.RateTransition11_Buffer0 =
    rtb_WebSocketServerSFunction_o1[7];
  rtExtModeUpload(2, (((XsensWebSocketAngleRefBandTe_M->Timing.clockTick2+
                        XsensWebSocketAngleRefBandTe_M->Timing.clockTickH2*
                        4294967296.0)) * 0.04));

  // Update absolute time
  // The "clockTick2" counts the number of times the code of this task has
  //  been executed. The resolution of this integer timer is 0.04, which is the step size
  //  of the task. Size of "clockTick2" ensures timer will not overflow during the
  //  application lifespan selected.
  //  Timer of this task consists of two 32 bit unsigned integers.
  //  The two integers represent the low bits Timing.clockTick2 and the high bits
  //  Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.

  XsensWebSocketAngleRefBandTe_M->Timing.clockTick2++;
  if (!XsensWebSocketAngleRefBandTe_M->Timing.clockTick2) {
    XsensWebSocketAngleRefBandTe_M->Timing.clockTickH2++;
  }
}

// Model initialize function
void XsensWebSocketAngleRefBandTest_v4_5_1_initialize(void)
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // initialize real-time model
  (void) memset((void *)XsensWebSocketAngleRefBandTe_M, 0,
                sizeof(RT_MODEL_XsensWebSocketAngleR_T));
  (XsensWebSocketAngleRefBandTe_M)->Timing.TaskCounters.cLimit[0] = 1;
  (XsensWebSocketAngleRefBandTe_M)->Timing.TaskCounters.cLimit[1] = 1;
  (XsensWebSocketAngleRefBandTe_M)->Timing.TaskCounters.cLimit[2] = 4;

  {
    // Setup solver object
    rtsiSetSimTimeStepPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                          &XsensWebSocketAngleRefBandTe_M->Timing.simTimeStep);
    rtsiSetTPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo, &rtmGetTPtr
                (XsensWebSocketAngleRefBandTe_M));
    rtsiSetStepSizePtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                       &XsensWebSocketAngleRefBandTe_M->Timing.stepSize0);
    rtsiSetdXPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                 &XsensWebSocketAngleRefBandTe_M->ModelData.derivs);
    rtsiSetContStatesPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo, (real_T **)
                         &XsensWebSocketAngleRefBandTe_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
      &XsensWebSocketAngleRefBandTe_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
      &XsensWebSocketAngleRefBandTe_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&XsensWebSocketAngleRefBandTe_M->solverInfo,
       &XsensWebSocketAngleRefBandTe_M->ModelData.periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&XsensWebSocketAngleRefBandTe_M->solverInfo,
       &XsensWebSocketAngleRefBandTe_M->ModelData.periodicContStateRanges);
    rtsiSetErrorStatusPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                          (&rtmGetErrorStatus(XsensWebSocketAngleRefBandTe_M)));
    rtsiSetRTModelPtr(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                      XsensWebSocketAngleRefBandTe_M);
  }

  rtsiSetSimTimeStep(&XsensWebSocketAngleRefBandTe_M->solverInfo,
                     MAJOR_TIME_STEP);
  XsensWebSocketAngleRefBandTe_M->ModelData.intgData.y =
    XsensWebSocketAngleRefBandTe_M->ModelData.odeY;
  XsensWebSocketAngleRefBandTe_M->ModelData.intgData.f[0] =
    XsensWebSocketAngleRefBandTe_M->ModelData.odeF[0];
  XsensWebSocketAngleRefBandTe_M->ModelData.intgData.f[1] =
    XsensWebSocketAngleRefBandTe_M->ModelData.odeF[1];
  XsensWebSocketAngleRefBandTe_M->ModelData.intgData.f[2] =
    XsensWebSocketAngleRefBandTe_M->ModelData.odeF[2];
  XsensWebSocketAngleRefBandTe_M->ModelData.contStates =
    ((X_XsensWebSocketAngleRefBandT_T *) &XsensWebSocketAngleRefBandTes_X);
  rtsiSetSolverData(&XsensWebSocketAngleRefBandTe_M->solverInfo, (void *)
                    &XsensWebSocketAngleRefBandTe_M->ModelData.intgData);
  rtsiSetSolverName(&XsensWebSocketAngleRefBandTe_M->solverInfo,"ode3");
  rtmSetTPtr(XsensWebSocketAngleRefBandTe_M,
             &XsensWebSocketAngleRefBandTe_M->Timing.tArray[0]);
  rtmSetTFinal(XsensWebSocketAngleRefBandTe_M, -1);
  XsensWebSocketAngleRefBandTe_M->Timing.stepSize0 = 0.01;

  // External mode info
  XsensWebSocketAngleRefBandTe_M->Sizes.checksums[0] = (3763490914U);
  XsensWebSocketAngleRefBandTe_M->Sizes.checksums[1] = (217613976U);
  XsensWebSocketAngleRefBandTe_M->Sizes.checksums[2] = (2903195143U);
  XsensWebSocketAngleRefBandTe_M->Sizes.checksums[3] = (4107147735U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[14];
    XsensWebSocketAngleRefBandTe_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    systemRan[13] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(XsensWebSocketAngleRefBandTe_M->extModeInfo,
      &XsensWebSocketAngleRefBandTe_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(XsensWebSocketAngleRefBandTe_M->extModeInfo,
                        XsensWebSocketAngleRefBandTe_M->Sizes.checksums);
    rteiSetTPtr(XsensWebSocketAngleRefBandTe_M->extModeInfo, rtmGetTPtr
                (XsensWebSocketAngleRefBandTe_M));
  }

  // block I/O
  (void) memset(((void *) &XsensWebSocketAngleRefBandTes_B), 0,
                sizeof(B_XsensWebSocketAngleRefBandT_T));

  // states (continuous)
  {
    (void) memset((void *)&XsensWebSocketAngleRefBandTes_X, 0,
                  sizeof(X_XsensWebSocketAngleRefBandT_T));
  }

  // states (dwork)
  (void) memset((void *)&XsensWebSocketAngleRefBandTe_DW, 0,
                sizeof(DW_XsensWebSocketAngleRefBand_T));

  // data type transition information
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    XsensWebSocketAngleRefBandTe_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    // Block I/O transition table
    dtInfo.B = &rtBTransTable;

    // Parameters transition table
    dtInfo.P = &rtPTransTable;
  }

  // Start for RateTransition: '<Root>/Rate Transition1'
  XsensWebSocketAngleRefBandTes_B.RateTransition1 =
    XsensWebSocketAngleRefBandTes_P.RateTransition1_X0;

  // Start for RateTransition: '<Root>/Rate Transition6'
  XsensWebSocketAngleRefBandTes_B.RateTransition6[0] =
    XsensWebSocketAngleRefBandTes_P.RateTransition6_X0;
  XsensWebSocketAngleRefBandTes_B.RateTransition6[1] =
    XsensWebSocketAngleRefBandTes_P.RateTransition6_X0;
  XsensWebSocketAngleRefBandTes_B.RateTransition6[2] =
    XsensWebSocketAngleRefBandTes_P.RateTransition6_X0;

  // Start for RateTransition: '<Root>/Rate Transition'
  XsensWebSocketAngleRefBandTes_B.RateTransition =
    XsensWebSocketAngleRefBandTes_P.RateTransition_X0;

  // Start for ToFile: '<Root>/To File'
  {
    FILE *fp = (NULL);
    char fileName[509] = "webSocketTestBand.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                        "Error creating .mat file webSocketTestBand.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp,6,0,"webTestBand")) {
      rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                        "Error writing mat file header to file webSocketTestBand.mat");
      return;
    }

    XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Count = 0;
    XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Decimation = -1;
    XsensWebSocketAngleRefBandTe_DW.ToFile_PWORK.FilePtr = fp;
  }

  // S-Function (ex_sfun_sci_xsens): <Root>/Xsens IMUs
  init_xsens( &XsensWebSocketAngleRefBandTe_DW.XsensIMUs_PWORK, (uint8_T*)
             XsensWebSocketAngleRefBandTes_P.XsensIMUs_p1, (uint32_T)19,
             (uint8_T*)XsensWebSocketAngleRefBandTes_P.XsensIMUs_p2, (uint32_T)6,
             (uint8_T*)&XsensWebSocketAngleRefBandTes_P.XsensIMUs_p3, (uint32_T)
             1, (uint8_T*)&XsensWebSocketAngleRefBandTes_P.XsensIMUs_p4,
             (uint32_T)1, (uint8_T*)
             &XsensWebSocketAngleRefBandTes_P.XsensIMUs_p5, (uint32_T)1,
             (uint8_T*)&XsensWebSocketAngleRefBandTes_P.XsensIMUs_p6, (uint32_T)
             1, (uint8_T*)&XsensWebSocketAngleRefBandTes_P.XsensIMUs_p7,
             (uint32_T)1, (uint8_T*)
             &XsensWebSocketAngleRefBandTes_P.XsensIMUs_p8, (uint32_T)1,
             (uint8_T*)&XsensWebSocketAngleRefBandTes_P.XsensIMUs_p9, (uint32_T)
             1, (uint8_T*)&XsensWebSocketAngleRefBandTes_P.XsensIMUs_p10,
             (uint32_T)1, (uint8_T*)
             &XsensWebSocketAngleRefBandTes_P.XsensIMUs_p11, (uint32_T)1,
             (uint32_T)XsensWebSocketAngleRefBandTes_P.XsensIMUs_p12, (uint32_T)
             XsensWebSocketAngleRefBandTes_P.XsensIMUs_p13);

  // Start for RateTransition: '<Root>/Rate Transition7'
  XsensWebSocketAngleRefBandTes_B.r[0] =
    XsensWebSocketAngleRefBandTes_P.RateTransition7_X0;
  XsensWebSocketAngleRefBandTes_B.r[1] =
    XsensWebSocketAngleRefBandTes_P.RateTransition7_X0;

  // Start for RateTransition: '<Root>/Rate Transition8'
  XsensWebSocketAngleRefBandTes_B.RateTransition8 =
    XsensWebSocketAngleRefBandTes_P.RateTransition8_X0;

  // Start for RateTransition: '<Root>/Rate Transition11'
  XsensWebSocketAngleRefBandTes_B.RateTransition11 =
    XsensWebSocketAngleRefBandTes_P.RateTransition11_X0;

  // S-Function (web_socket_server): <S7>/WebSocketServer SFunction
  init_webSocketServer
    ( &XsensWebSocketAngleRefBandTe_DW.WebSocketServerSFunction_PWORK, (uint8_T*)
     XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p1, (uint16_T)5,
     (uint8_T*)XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p2,
     (uint16_T)5, (uint8_T*)
     XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p3, (uint16_T)5,
     (uint8_T*)XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p4,
     (uint16_T)101, (uint16_T)((uint16_T)8U), (uint16_T)((uint16_T)11U),
     (uint16_T)XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p7,
     (uint8_T*)XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p8,
     (uint16_T)9, (uint16_T)
     XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p9, (uint8_T*)
     XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p10, (uint16_T)3);

  // InitializeConditions for RateTransition: '<Root>/Rate Transition1'
  XsensWebSocketAngleRefBandTe_DW.RateTransition1_Buffer0 =
    XsensWebSocketAngleRefBandTes_P.RateTransition1_X0;

  // InitializeConditions for RateTransition: '<Root>/Rate Transition6'
  XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[0] =
    XsensWebSocketAngleRefBandTes_P.RateTransition6_X0;
  XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[1] =
    XsensWebSocketAngleRefBandTes_P.RateTransition6_X0;
  XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0[2] =
    XsensWebSocketAngleRefBandTes_P.RateTransition6_X0;

  // InitializeConditions for RateTransition: '<Root>/Rate Transition'
  XsensWebSocketAngleRefBandTe_DW.RateTransition_Buffer0 =
    XsensWebSocketAngleRefBandTes_P.RateTransition_X0;

  // InitializeConditions for MATLAB Function: '<S2>/Extractor'
  XsensWebSocketAngleRefBandTe_DW.lastSampleNumber = 0.0;
  XsensWebSocketAngleRefBandTe_DW.lastFactor = 1.0;

  // InitializeConditions for TransferFcn: '<S6>/Transfer Fcn'
  XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[0] = 0.0;

  // InitializeConditions for TransferFcn: '<S6>/Transfer Fcn1'
  XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[0] = 0.0;

  // InitializeConditions for RateTransition: '<Root>/Rate Transition7'
  XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0[0] =
    XsensWebSocketAngleRefBandTes_P.RateTransition7_X0;

  // InitializeConditions for TransferFcn: '<S6>/Transfer Fcn'
  XsensWebSocketAngleRefBandTes_X.TransferFcn_CSTATE[1] = 0.0;

  // InitializeConditions for TransferFcn: '<S6>/Transfer Fcn1'
  XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE[1] = 0.0;

  // InitializeConditions for RateTransition: '<Root>/Rate Transition7'
  XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0[1] =
    XsensWebSocketAngleRefBandTes_P.RateTransition7_X0;

  // InitializeConditions for RateTransition: '<Root>/Rate Transition8'
  XsensWebSocketAngleRefBandTe_DW.RateTransition8_Buffer0 =
    XsensWebSocketAngleRefBandTes_P.RateTransition8_X0;

  // InitializeConditions for Integrator: '<S4>/Integrator'
  XsensWebSocketAngleRefBandTes_X.Integrator_CSTATE =
    XsensWebSocketAngleRefBandTes_P.Integrator_IC;

  // InitializeConditions for TransferFcn: '<S4>/Transfer Fcn2'
  XsensWebSocketAngleRefBandTes_X.TransferFcn2_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<S4>/Integrator1'
  XsensWebSocketAngleRefBandTes_X.Integrator1_CSTATE =
    XsensWebSocketAngleRefBandTes_P.Integrator1_IC;

  // InitializeConditions for TransferFcn: '<S4>/Transfer Fcn1'
  XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE_f = 0.0;

  // InitializeConditions for Integrator: '<S5>/Integrator'
  XsensWebSocketAngleRefBandTes_X.Integrator_CSTATE_e =
    XsensWebSocketAngleRefBandTes_P.Integrator_IC_a;

  // InitializeConditions for TransferFcn: '<S5>/Transfer Fcn2'
  XsensWebSocketAngleRefBandTes_X.TransferFcn2_CSTATE_d = 0.0;

  // InitializeConditions for Integrator: '<S5>/Integrator1'
  XsensWebSocketAngleRefBandTes_X.Integrator1_CSTATE_g =
    XsensWebSocketAngleRefBandTes_P.Integrator1_IC_n;

  // InitializeConditions for TransferFcn: '<S5>/Transfer Fcn1'
  XsensWebSocketAngleRefBandTes_X.TransferFcn1_CSTATE_e = 0.0;

  // InitializeConditions for RateTransition: '<Root>/Rate Transition11'
  XsensWebSocketAngleRefBandTe_DW.RateTransition11_Buffer0 =
    XsensWebSocketAngleRefBandTes_P.RateTransition11_X0;
}

// Model terminate function
void XsensWebSocketAngleRefBandTest_v4_5_1_terminate(void)
{
  // Terminate for ToFile: '<Root>/To File'
  {
    FILE *fp = (FILE *) XsensWebSocketAngleRefBandTe_DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "webSocketTestBand.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                          "Error closing MAT-file webSocketTestBand.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                          "Error reopening MAT-file webSocketTestBand.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 6,
           XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Count, "webTestBand")) {
        rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                          "Error writing header for webTestBand to MAT-file webSocketTestBand.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(XsensWebSocketAngleRefBandTe_M,
                          "Error closing MAT-file webSocketTestBand.mat");
        return;
      }

      XsensWebSocketAngleRefBandTe_DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }

  // S-Function (ex_sfun_sci_xsens): <Root>/Xsens IMUs
  terminate_xsens( &XsensWebSocketAngleRefBandTe_DW.XsensIMUs_PWORK);

  // S-Function (web_socket_server): <S7>/WebSocketServer SFunction
  terminate_webSocketServer
    ( &XsensWebSocketAngleRefBandTe_DW.WebSocketServerSFunction_PWORK);
}

//
// File trailer for generated code.
//
// [EOF]
//
