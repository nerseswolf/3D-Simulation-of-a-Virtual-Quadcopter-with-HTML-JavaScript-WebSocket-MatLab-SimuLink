  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 5;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (XsensWebSocketAngleRefBandTes_P)
    ;%
      section.nData     = 47;
      section.data(47)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_P.CompareToConstant_const
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch1_Threshold
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Extractor_correction
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch2_Threshold
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch_Threshold
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch3_Threshold
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch1_Threshold_j
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% XsensWebSocketAngleRefBandTes_P.RateTransition1_X0
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% XsensWebSocketAngleRefBandTes_P.RateTransition6_X0
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn_A
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn_C
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 11;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 13;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 14;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_A
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 15;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_C
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 17;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Saturation1_UpperSat
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 19;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Saturation1_LowerSat
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 20;
	
	  ;% XsensWebSocketAngleRefBandTes_P.RateTransition7_X0
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 21;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Constant_Value
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 22;
	
	  ;% XsensWebSocketAngleRefBandTes_P.RateTransition8_X0
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 24;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch_Threshold_i
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 25;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Integrator_IC
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 26;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn2_A
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 27;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn2_C
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 28;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn2_D
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 29;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Integrator1_IC
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 30;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_A_g
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 31;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_C_m
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 32;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_D
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 33;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Constant_Value_b
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 34;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch_Threshold_d
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 36;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Integrator_IC_a
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 37;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn2_A_l
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 38;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn2_C_c
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 39;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn2_D_c
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 40;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Integrator1_IC_n
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 41;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_A_b
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 42;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_C_n
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 43;
	
	  ;% XsensWebSocketAngleRefBandTes_P.TransferFcn1_D_o
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 44;
	
	  ;% XsensWebSocketAngleRefBandTes_P.RateTransition11_X0
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 45;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch_Threshold_p
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 46;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Saturation_UpperSat_n
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 47;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Saturation_LowerSat_e
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 48;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Constant_Value_f
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 49;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Constant1_Value
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 50;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch4_Threshold
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 51;
	
	  ;% XsensWebSocketAngleRefBandTes_P.Switch5_Threshold
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 52;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_P.RateTransition_X0
	  section.data(1).logicalSrcIdx = 47;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p12
	  section.data(1).logicalSrcIdx = 48;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p13
	  section.data(2).logicalSrcIdx = 49;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(3) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p7
	  section.data(1).logicalSrcIdx = 50;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p9
	  section.data(2).logicalSrcIdx = 51;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(4) = section;
      clear section
      
      section.nData     = 17;
      section.data(17)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p1
	  section.data(1).logicalSrcIdx = 52;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p2
	  section.data(2).logicalSrcIdx = 53;
	  section.data(2).dtTransOffset = 19;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p3
	  section.data(3).logicalSrcIdx = 54;
	  section.data(3).dtTransOffset = 25;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p4
	  section.data(4).logicalSrcIdx = 55;
	  section.data(4).dtTransOffset = 26;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p5
	  section.data(5).logicalSrcIdx = 56;
	  section.data(5).dtTransOffset = 27;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p6
	  section.data(6).logicalSrcIdx = 57;
	  section.data(6).dtTransOffset = 28;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p7
	  section.data(7).logicalSrcIdx = 58;
	  section.data(7).dtTransOffset = 29;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p8
	  section.data(8).logicalSrcIdx = 59;
	  section.data(8).dtTransOffset = 30;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p9
	  section.data(9).logicalSrcIdx = 60;
	  section.data(9).dtTransOffset = 31;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p10
	  section.data(10).logicalSrcIdx = 61;
	  section.data(10).dtTransOffset = 32;
	
	  ;% XsensWebSocketAngleRefBandTes_P.XsensIMUs_p11
	  section.data(11).logicalSrcIdx = 62;
	  section.data(11).dtTransOffset = 33;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p1
	  section.data(12).logicalSrcIdx = 63;
	  section.data(12).dtTransOffset = 34;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p2
	  section.data(13).logicalSrcIdx = 64;
	  section.data(13).dtTransOffset = 39;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p3
	  section.data(14).logicalSrcIdx = 65;
	  section.data(14).dtTransOffset = 44;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p4
	  section.data(15).logicalSrcIdx = 66;
	  section.data(15).dtTransOffset = 49;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p8
	  section.data(16).logicalSrcIdx = 67;
	  section.data(16).dtTransOffset = 150;
	
	  ;% XsensWebSocketAngleRefBandTes_P.WebSocketServerSFunction_p10
	  section.data(17).logicalSrcIdx = 68;
	  section.data(17).dtTransOffset = 159;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(5) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (XsensWebSocketAngleRefBandTes_B)
    ;%
      section.nData     = 25;
      section.data(25)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_B.RateTransition1
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTes_B.RateTransition6
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% XsensWebSocketAngleRefBandTes_B.DataTypeConversion
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 4;
	
	  ;% XsensWebSocketAngleRefBandTes_B.TmpSignalConversionAtToFileInpo
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 5;
	
	  ;% XsensWebSocketAngleRefBandTes_B.r
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 10;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Constant
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 12;
	
	  ;% XsensWebSocketAngleRefBandTes_B.RateTransition8
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 14;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Product1
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 15;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Product4
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 16;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Product
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 17;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Product3
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 18;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Constant_a
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 19;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Switch
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 21;
	
	  ;% XsensWebSocketAngleRefBandTes_B.RateTransition11
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 23;
	
	  ;% XsensWebSocketAngleRefBandTes_B.time
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 24;
	
	  ;% XsensWebSocketAngleRefBandTes_B.quat
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 25;
	
	  ;% XsensWebSocketAngleRefBandTes_B.u
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 29;
	
	  ;% XsensWebSocketAngleRefBandTes_B.y
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 31;
	
	  ;% XsensWebSocketAngleRefBandTes_B.error
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 33;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Constant_a3
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 35;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Constant1
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 36;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Switch4
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 37;
	
	  ;% XsensWebSocketAngleRefBandTes_B.Switch5
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 38;
	
	  ;% XsensWebSocketAngleRefBandTes_B.u_n
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 39;
	
	  ;% XsensWebSocketAngleRefBandTes_B.q
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 41;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTes_B.RateTransition
	  section.data(1).logicalSrcIdx = 25;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 4;
    sectIdxOffset = 2;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (XsensWebSocketAngleRefBandTe_DW)
    ;%
      section.nData     = 7;
      section.data(7)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTe_DW.RateTransition1_Buffer0
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.RateTransition6_Buffer0
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.RateTransition7_Buffer0
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 4;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.RateTransition8_Buffer0
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 6;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.RateTransition11_Buffer0
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 7;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.lastSampleNumber
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 8;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.lastFactor
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 9;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 5;
      section.data(5)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTe_DW.Scope_PWORK.LoggedData
	  section.data(1).logicalSrcIdx = 7;
	  section.data(1).dtTransOffset = 0;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.ToFile_PWORK.FilePtr
	  section.data(2).logicalSrcIdx = 8;
	  section.data(2).dtTransOffset = 1;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.XsensIMUs_PWORK
	  section.data(3).logicalSrcIdx = 9;
	  section.data(3).dtTransOffset = 2;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.quat_PWORK.LoggedData
	  section.data(4).logicalSrcIdx = 10;
	  section.data(4).dtTransOffset = 3;
	
	  ;% XsensWebSocketAngleRefBandTe_DW.WebSocketServerSFunction_PWORK
	  section.data(5).logicalSrcIdx = 11;
	  section.data(5).dtTransOffset = 4;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTe_DW.RateTransition_Buffer0
	  section.data(1).logicalSrcIdx = 12;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% XsensWebSocketAngleRefBandTe_DW.ToFile_IWORK.Count
	  section.data(1).logicalSrcIdx = 13;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 3763490914;
  targMap.checksum1 = 217613976;
  targMap.checksum2 = 2903195143;
  targMap.checksum3 = 4107147735;

