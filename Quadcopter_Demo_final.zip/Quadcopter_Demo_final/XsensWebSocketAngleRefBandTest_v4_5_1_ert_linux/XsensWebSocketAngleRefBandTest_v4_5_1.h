//
// File: XsensWebSocketAngleRefBandTest_v4_5_1.h
//
// Code generated for Simulink model 'XsensWebSocketAngleRefBandTest_v4_5_1'.
//
// Model version                  : 1.88
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Tue Jul 18 14:05:15 2017
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_XsensWebSocketAngleRefBandTest_v4_5_1_h_
#define RTW_HEADER_XsensWebSocketAngleRefBandTest_v4_5_1_h_
#include <stddef.h>
#include <math.h>
#include <float.h>
#include <string.h>
#ifndef XsensWebSocketAngleRefBandTest_v4_5_1_COMMON_INCLUDES_
# define XsensWebSocketAngleRefBandTest_v4_5_1_COMMON_INCLUDES_
#include <stdio.h>
#include <string.h>
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "sci_xsens.hpp"
#include "xsens.h"
#include "serialkey.h"
#include "sci_WebSocketServer.hpp"
#include "webSocketServer.h"
#include "json.h"
#endif                                 // XsensWebSocketAngleRefBandTest_v4_5_1_COMMON_INCLUDES_ 

#include "XsensWebSocketAngleRefBandTest_v4_5_1_types.h"

// Shared type includes
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetBlkStateChangeFlag
# define rtmGetBlkStateChangeFlag(rtm) ((rtm)->ModelData.blkStateChange)
#endif

#ifndef rtmSetBlkStateChangeFlag
# define rtmSetBlkStateChangeFlag(rtm, val) ((rtm)->ModelData.blkStateChange = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->ModelData.contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->ModelData.contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->ModelData.contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->ModelData.contStates = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->ModelData.derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->ModelData.derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->ModelData.intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->ModelData.intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->ModelData.odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->ModelData.odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->ModelData.odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->ModelData.odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->ModelData.periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->ModelData.periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->ModelData.periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->ModelData.periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->ModelData.zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->ModelData.zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->ModelData.derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->ModelData.derivs = (val))
#endif

#ifndef rtmCounterLimit
# define rtmCounterLimit(rtm, idx)     ((rtm)->Timing.TaskCounters.cLimit[(idx)])
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#define XsensWebSocketAngleRefBandTest_v4_5_1_M (XsensWebSocketAngleRefBandTe_M)

// Block signals (auto storage)
typedef struct {
  real_T RateTransition1;              // '<Root>/Rate Transition1'
  real_T RateTransition6[3];           // '<Root>/Rate Transition6'
  real_T DataTypeConversion;           // '<Root>/Data Type Conversion'
  real_T TmpSignalConversionAtToFileInpo[5];
  real_T r[2];                         // '<Root>/Rate Transition7'
  real_T Constant[2];                  // '<S4>/Constant'
  real_T RateTransition8;              // '<Root>/Rate Transition8'
  real_T Product1;                     // '<S4>/Product1'
  real_T Product4;                     // '<S4>/Product4'
  real_T Product;                      // '<S4>/Product'
  real_T Product3;                     // '<S4>/Product3'
  real_T Constant_a[2];                // '<S5>/Constant'
  real_T Switch[2];                    // '<S5>/Switch'
  real_T RateTransition11;             // '<Root>/Rate Transition11'
  real_T time;                         // '<Root>/Rate Transition2'
  real_T quat[4];                      // '<Root>/Rate Transition3'
  real_T u[2];                         // '<Root>/Rate Transition4'
  real_T y[2];                         // '<Root>/Rate Transition5'
  real_T error[2];                     // '<Root>/Rate Transition9'
  real_T Constant_a3;                  // '<S6>/Constant'
  real_T Constant1;                    // '<S6>/Constant1'
  real_T Switch4;                      // '<S6>/Switch4'
  real_T Switch5;                      // '<S6>/Switch5'
  real_T u_n[2];                       // '<Root>/MATLAB Function'
  real_T q[4];                         // '<S2>/Extractor'
  int32_T RateTransition;              // '<Root>/Rate Transition'
} B_XsensWebSocketAngleRefBandT_T;

// Block states (auto storage) for system '<Root>'
typedef struct {
  real_T RateTransition1_Buffer0;      // '<Root>/Rate Transition1'
  real_T RateTransition6_Buffer0[3];   // '<Root>/Rate Transition6'
  real_T RateTransition7_Buffer0[2];   // '<Root>/Rate Transition7'
  real_T RateTransition8_Buffer0;      // '<Root>/Rate Transition8'
  real_T RateTransition11_Buffer0;     // '<Root>/Rate Transition11'
  real_T lastSampleNumber;             // '<S2>/Extractor'
  real_T lastFactor;                   // '<S2>/Extractor'
  struct {
    void *LoggedData;
  } Scope_PWORK;                       // '<Root>/Scope'

  struct {
    void *FilePtr;
  } ToFile_PWORK;                      // '<Root>/To File'

  void *XsensIMUs_PWORK;               // '<Root>/Xsens IMUs'
  struct {
    void *LoggedData;
  } quat_PWORK;                        // '<Root>/quat'

  void *WebSocketServerSFunction_PWORK;// '<S7>/WebSocketServer SFunction'
  int32_T RateTransition_Buffer0;      // '<Root>/Rate Transition'
  struct {
    int_T Count;
    int_T Decimation;
  } ToFile_IWORK;                      // '<Root>/To File'
} DW_XsensWebSocketAngleRefBand_T;

// Continuous states (auto storage)
typedef struct {
  real_T TransferFcn_CSTATE[2];        // '<S6>/Transfer Fcn'
  real_T TransferFcn1_CSTATE[2];       // '<S6>/Transfer Fcn1'
  real_T Integrator_CSTATE;            // '<S4>/Integrator'
  real_T TransferFcn2_CSTATE;          // '<S4>/Transfer Fcn2'
  real_T Integrator1_CSTATE;           // '<S4>/Integrator1'
  real_T TransferFcn1_CSTATE_f;        // '<S4>/Transfer Fcn1'
  real_T Integrator_CSTATE_e;          // '<S5>/Integrator'
  real_T TransferFcn2_CSTATE_d;        // '<S5>/Transfer Fcn2'
  real_T Integrator1_CSTATE_g;         // '<S5>/Integrator1'
  real_T TransferFcn1_CSTATE_e;        // '<S5>/Transfer Fcn1'
} X_XsensWebSocketAngleRefBandT_T;

// State derivatives (auto storage)
typedef struct {
  real_T TransferFcn_CSTATE[2];        // '<S6>/Transfer Fcn'
  real_T TransferFcn1_CSTATE[2];       // '<S6>/Transfer Fcn1'
  real_T Integrator_CSTATE;            // '<S4>/Integrator'
  real_T TransferFcn2_CSTATE;          // '<S4>/Transfer Fcn2'
  real_T Integrator1_CSTATE;           // '<S4>/Integrator1'
  real_T TransferFcn1_CSTATE_f;        // '<S4>/Transfer Fcn1'
  real_T Integrator_CSTATE_e;          // '<S5>/Integrator'
  real_T TransferFcn2_CSTATE_d;        // '<S5>/Transfer Fcn2'
  real_T Integrator1_CSTATE_g;         // '<S5>/Integrator1'
  real_T TransferFcn1_CSTATE_e;        // '<S5>/Transfer Fcn1'
} XDot_XsensWebSocketAngleRefBa_T;

// State disabled
typedef struct {
  boolean_T TransferFcn_CSTATE[2];     // '<S6>/Transfer Fcn'
  boolean_T TransferFcn1_CSTATE[2];    // '<S6>/Transfer Fcn1'
  boolean_T Integrator_CSTATE;         // '<S4>/Integrator'
  boolean_T TransferFcn2_CSTATE;       // '<S4>/Transfer Fcn2'
  boolean_T Integrator1_CSTATE;        // '<S4>/Integrator1'
  boolean_T TransferFcn1_CSTATE_f;     // '<S4>/Transfer Fcn1'
  boolean_T Integrator_CSTATE_e;       // '<S5>/Integrator'
  boolean_T TransferFcn2_CSTATE_d;     // '<S5>/Transfer Fcn2'
  boolean_T Integrator1_CSTATE_g;      // '<S5>/Integrator1'
  boolean_T TransferFcn1_CSTATE_e;     // '<S5>/Transfer Fcn1'
} XDis_XsensWebSocketAngleRefBa_T;

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
typedef struct {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
} ODE3_IntgData;

#endif

// Parameters (auto storage)
struct P_XsensWebSocketAngleRefBandT_T_ {
  real_T CompareToConstant_const;      // Mask Parameter: CompareToConstant_const
                                       //  Referenced by: '<S1>/Constant'

  real_T Switch1_Threshold;            // Expression: 1
                                       //  Referenced by: '<Root>/Switch1'

  real_T Extractor_correction;         // Expression: correction
                                       //  Referenced by: '<S2>/Extractor'

  real_T Switch2_Threshold;            // Expression: -45
                                       //  Referenced by: '<S6>/Switch2'

  real_T Switch_Threshold;             // Expression: 45
                                       //  Referenced by: '<S6>/Switch'

  real_T Switch3_Threshold;            // Expression: -45
                                       //  Referenced by: '<S6>/Switch3'

  real_T Switch1_Threshold_j;          // Expression: 45
                                       //  Referenced by: '<S6>/Switch1'

  real_T RateTransition1_X0;           // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition1'

  real_T RateTransition6_X0;           // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition6'

  real_T TransferFcn_A[2];             // Computed Parameter: TransferFcn_A
                                       //  Referenced by: '<S6>/Transfer Fcn'

  real_T TransferFcn_C[2];             // Computed Parameter: TransferFcn_C
                                       //  Referenced by: '<S6>/Transfer Fcn'

  real_T Saturation_UpperSat;          // Expression: 50
                                       //  Referenced by: '<S6>/Saturation'

  real_T Saturation_LowerSat;          // Expression: -50
                                       //  Referenced by: '<S6>/Saturation'

  real_T TransferFcn1_A[2];            // Computed Parameter: TransferFcn1_A
                                       //  Referenced by: '<S6>/Transfer Fcn1'

  real_T TransferFcn1_C[2];            // Computed Parameter: TransferFcn1_C
                                       //  Referenced by: '<S6>/Transfer Fcn1'

  real_T Saturation1_UpperSat;         // Expression: 50
                                       //  Referenced by: '<S6>/Saturation1'

  real_T Saturation1_LowerSat;         // Expression: -50
                                       //  Referenced by: '<S6>/Saturation1'

  real_T RateTransition7_X0;           // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition7'

  real_T Constant_Value[2];            // Expression: [0 0]
                                       //  Referenced by: '<S4>/Constant'

  real_T RateTransition8_X0;           // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition8'

  real_T Switch_Threshold_i;           // Expression: 1
                                       //  Referenced by: '<S4>/Switch'

  real_T Integrator_IC;                // Expression: 0
                                       //  Referenced by: '<S4>/Integrator'

  real_T TransferFcn2_A;               // Computed Parameter: TransferFcn2_A
                                       //  Referenced by: '<S4>/Transfer Fcn2'

  real_T TransferFcn2_C;               // Computed Parameter: TransferFcn2_C
                                       //  Referenced by: '<S4>/Transfer Fcn2'

  real_T TransferFcn2_D;               // Computed Parameter: TransferFcn2_D
                                       //  Referenced by: '<S4>/Transfer Fcn2'

  real_T Integrator1_IC;               // Expression: 0
                                       //  Referenced by: '<S4>/Integrator1'

  real_T TransferFcn1_A_g;             // Computed Parameter: TransferFcn1_A_g
                                       //  Referenced by: '<S4>/Transfer Fcn1'

  real_T TransferFcn1_C_m;             // Computed Parameter: TransferFcn1_C_m
                                       //  Referenced by: '<S4>/Transfer Fcn1'

  real_T TransferFcn1_D;               // Computed Parameter: TransferFcn1_D
                                       //  Referenced by: '<S4>/Transfer Fcn1'

  real_T Constant_Value_b[2];          // Expression: [0 0]
                                       //  Referenced by: '<S5>/Constant'

  real_T Switch_Threshold_d;           // Expression: 1
                                       //  Referenced by: '<S5>/Switch'

  real_T Integrator_IC_a;              // Expression: 0
                                       //  Referenced by: '<S5>/Integrator'

  real_T TransferFcn2_A_l;             // Computed Parameter: TransferFcn2_A_l
                                       //  Referenced by: '<S5>/Transfer Fcn2'

  real_T TransferFcn2_C_c;             // Computed Parameter: TransferFcn2_C_c
                                       //  Referenced by: '<S5>/Transfer Fcn2'

  real_T TransferFcn2_D_c;             // Computed Parameter: TransferFcn2_D_c
                                       //  Referenced by: '<S5>/Transfer Fcn2'

  real_T Integrator1_IC_n;             // Expression: 0
                                       //  Referenced by: '<S5>/Integrator1'

  real_T TransferFcn1_A_b;             // Computed Parameter: TransferFcn1_A_b
                                       //  Referenced by: '<S5>/Transfer Fcn1'

  real_T TransferFcn1_C_n;             // Computed Parameter: TransferFcn1_C_n
                                       //  Referenced by: '<S5>/Transfer Fcn1'

  real_T TransferFcn1_D_o;             // Computed Parameter: TransferFcn1_D_o
                                       //  Referenced by: '<S5>/Transfer Fcn1'

  real_T RateTransition11_X0;          // Expression: 0
                                       //  Referenced by: '<Root>/Rate Transition11'

  real_T Switch_Threshold_p;           // Expression: 1
                                       //  Referenced by: '<Root>/Switch'

  real_T Saturation_UpperSat_n;        // Expression: 1.5
                                       //  Referenced by: '<Root>/Saturation'

  real_T Saturation_LowerSat_e;        // Expression: -1.5
                                       //  Referenced by: '<Root>/Saturation'

  real_T Constant_Value_f;             // Expression: 0
                                       //  Referenced by: '<S6>/Constant'

  real_T Constant1_Value;              // Expression: 0
                                       //  Referenced by: '<S6>/Constant1'

  real_T Switch4_Threshold;            // Expression: 0
                                       //  Referenced by: '<S6>/Switch4'

  real_T Switch5_Threshold;            // Expression: 0
                                       //  Referenced by: '<S6>/Switch5'

  int32_T RateTransition_X0;           // Computed Parameter: RateTransition_X0
                                       //  Referenced by: '<Root>/Rate Transition'

  uint32_T XsensIMUs_p12;              // Expression: uint32(Freq)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint32_T XsensIMUs_p13;              // Expression: uint32(UseCalibratedValues)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint16_T WebSocketServerSFunction_p7;// Computed Parameter: WebSocketServerSFunction_p7
                                       //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint16_T WebSocketServerSFunction_p9;// Computed Parameter: WebSocketServerSFunction_p9
                                       //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint8_T XsensIMUs_p1[19];            // Expression: uint8(SID00)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p2[6];             // Expression: uint8(SID01)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p3;                // Expression: uint8(SID02)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p4;                // Expression: uint8(SID03)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p5;                // Expression: uint8(SID04)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p6;                // Expression: uint8(SID05)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p7;                // Expression: uint8(SID06)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p8;                // Expression: uint8(SID07)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p9;                // Expression: uint8(SID08)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p10;               // Expression: uint8(SID09)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p11;               // Expression: uint8(SID10)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T WebSocketServerSFunction_p1[5];// Computed Parameter: WebSocketServerSFunction_p1
                                         //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint8_T WebSocketServerSFunction_p2[5];// Computed Parameter: WebSocketServerSFunction_p2
                                         //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint8_T WebSocketServerSFunction_p3[5];// Computed Parameter: WebSocketServerSFunction_p3
                                         //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint8_T WebSocketServerSFunction_p4[101];// Expression: unicode2native(jsonBlockConfig, 'ISO-8859-1')
                                           //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint8_T WebSocketServerSFunction_p8[9];// Expression: unicode2native(address, 'ISO-8859-1')
                                         //  Referenced by: '<S7>/WebSocketServer SFunction'

  uint8_T WebSocketServerSFunction_p10[3];// Expression: unicode2native(resource, 'ISO-8859-1')
                                          //  Referenced by: '<S7>/WebSocketServer SFunction'

};

// Real-time Model Data Structure
struct tag_RTM_XsensWebSocketAngleRe_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  //
  //  ModelData:
  //  The following substructure contains information regarding
  //  the data used in the model.

  struct {
    X_XsensWebSocketAngleRefBandT_T *contStates;
    int_T *periodicContStateIndices;
    real_T *periodicContStateRanges;
    real_T *derivs;
    boolean_T *contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T blkStateChange;
    real_T odeY[12];
    real_T odeF[3][12];
    ODE3_IntgData intgData;
  } ModelData;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    uint32_T checksums[4];
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  SpecialInfo:
  //  The following substructure contains special information
  //  related to other components that are dependent on RTW.

  struct {
    const void *mappingInfo;
  } SpecialInfo;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    struct {
      uint8_T TID[3];
      uint8_T cLimit[3];
    } TaskCounters;

    struct {
      uint8_T TID0_2;
      uint8_T TID1_2;
    } RateInteraction;

    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[3];
  } Timing;
};

// Block parameters (auto storage)
#ifdef __cplusplus

extern "C" {

#endif

  extern P_XsensWebSocketAngleRefBandT_T XsensWebSocketAngleRefBandTes_P;

#ifdef __cplusplus

}
#endif

// Block signals (auto storage)
extern B_XsensWebSocketAngleRefBandT_T XsensWebSocketAngleRefBandTes_B;

// Continuous states (auto storage)
extern X_XsensWebSocketAngleRefBandT_T XsensWebSocketAngleRefBandTes_X;

// Block states (auto storage)
extern DW_XsensWebSocketAngleRefBand_T XsensWebSocketAngleRefBandTe_DW;

#ifdef __cplusplus

extern "C" {

#endif

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  // Model entry point functions
  extern void XsensWebSocketAngleRefBandTest_v4_5_1_initialize(void);
  extern void XsensWebSocketAngleRefBandTest_v4_5_1_step0(void);
  extern void XsensWebSocketAngleRefBandTest_v4_5_1_step2(void);
  extern void XsensWebSocketAngleRefBandTest_v4_5_1_terminate(void);

#ifdef __cplusplus

}
#endif

// Real-time Model object
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_XsensWebSocketAngleR_T *const XsensWebSocketAngleRefBandTe_M;

#ifdef __cplusplus

}
#endif

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'XsensWebSocketAngleRefBandTest_v4_5_1'
//  '<S1>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/Compare To Constant'
//  '<S2>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/Extract'
//  '<S3>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/MATLAB Function'
//  '<S4>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/PID-Controller'
//  '<S5>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/PID-Controller1'
//  '<S6>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/System Dynamics'
//  '<S7>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/WebSocket Server'
//  '<S8>'   : 'XsensWebSocketAngleRefBandTest_v4_5_1/Extract/Extractor'

#endif                                 // RTW_HEADER_XsensWebSocketAngleRefBandTest_v4_5_1_h_ 

//
// File trailer for generated code.
//
// [EOF]
//
